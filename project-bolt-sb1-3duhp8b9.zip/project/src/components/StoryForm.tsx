import React, { useState } from 'react';
import { PenLine, BookOpen, Tags } from 'lucide-react';

interface StoryFormProps {
  onSubmit: (data: {
    title: string;
    genre: string;
    hints: string[];
    wordCount: number;
  }) => void;
}

export function StoryForm({ onSubmit }: StoryFormProps) {
  const [title, setTitle] = useState("");
  const [genre, setGenre] = useState("fantasy");
  const [hints, setHints] = useState<string[]>([""]);
  const [wordCount, setWordCount] = useState(200);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      title,
      genre,
      hints: hints.filter(h => h.trim() !== ""),
      wordCount
    });
  };

  const addHint = () => setHints([...hints, ""]);
  const updateHint = (index: number, value: string) => {
    const newHints = [...hints];
    newHints[index] = value;
    setHints(newHints);
  };

  const genreStyles: Record<string, { bg: string, border: string, text: string }> = {
    magic: {
      bg: 'bg-purple-900/20',
      border: 'border-purple-300/30',
      text: 'text-purple-100'
    },
    fantasy: {
      bg: 'bg-violet-900/20',
      border: 'border-violet-300/30',
      text: 'text-violet-100'
    },
    horror: {
      bg: 'bg-red-900/20',
      border: 'border-red-300/30',
      text: 'text-red-100'
    },
    adventure: {
      bg: 'bg-amber-900/20',
      border: 'border-amber-300/30',
      text: 'text-amber-100'
    },
    historical: {
      bg: 'bg-orange-900/20',
      border: 'border-orange-300/30',
      text: 'text-orange-100'
    },
    romance: {
      bg: 'bg-pink-900/20',
      border: 'border-pink-300/30',
      text: 'text-pink-100'
    },
    scifi: {
      bg: 'bg-blue-900/20',
      border: 'border-blue-300/30',
      text: 'text-blue-100'
    },
    mystery: {
      bg: 'bg-emerald-900/20',
      border: 'border-emerald-300/30',
      text: 'text-emerald-100'
    }
  };

  const currentStyle = genreStyles[genre];

  return (
    <form 
      onSubmit={handleSubmit} 
      className={`space-y-6 p-6 rounded-xl border backdrop-blur-md ${currentStyle.bg} ${currentStyle.border} transition-all duration-300`}
    >
      <div>
        <label className={`block text-sm font-medium mb-2 flex items-center gap-2 ${currentStyle.text}`}>
          <PenLine size={18} />
          Story Title
        </label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-md shadow-sm focus:ring-2 focus:ring-opacity-50 focus:ring-white/50 focus:border-white/50 text-white backdrop-blur-sm transition-all duration-200"
          required
        />
      </div>

      <div>
        <label className={`block text-sm font-medium mb-2 flex items-center gap-2 ${currentStyle.text}`}>
          <BookOpen size={18} />
          Genre
        </label>
        <select
          value={genre}
          onChange={(e) => setGenre(e.target.value)}
          className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-md shadow-sm focus:ring-2 focus:ring-opacity-50 focus:ring-white/50 focus:border-white/50 text-white backdrop-blur-sm transition-all duration-200"
          style={{ color: 'white' }}
        >
          <option value="magic" className="bg-purple-900 text-white">Magic</option>
          <option value="fantasy" className="bg-violet-900 text-white">Fantasy</option>
          <option value="horror" className="bg-red-900 text-white">Horror</option>
          <option value="adventure" className="bg-amber-900 text-white">Adventure</option>
          <option value="historical" className="bg-orange-900 text-white">Historical</option>
          <option value="romance" className="bg-pink-900 text-white">Romance</option>
          <option value="scifi" className="bg-blue-900 text-white">Science Fiction</option>
          <option value="mystery" className="bg-emerald-900 text-white">Mystery</option>
        </select>
      </div>

      <div>
        <label className={`block text-sm font-medium mb-2 flex items-center gap-2 ${currentStyle.text}`}>
          <Tags size={18} />
          Story Hints
        </label>
        <div className="space-y-2">
          {hints.map((hint, index) => (
            <input
              key={index}
              type="text"
              value={hint}
              onChange={(e) => updateHint(index, e.target.value)}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-md shadow-sm focus:ring-2 focus:ring-opacity-50 focus:ring-white/50 focus:border-white/50 text-white backdrop-blur-sm transition-all duration-200"
              placeholder={`Hint ${index + 1}`}
            />
          ))}
          <button
            type="button"
            onClick={addHint}
            className={`text-sm ${currentStyle.text} hover:text-white transition-colors duration-200`}
          >
            + Add another hint
          </button>
        </div>
      </div>

      <div>
        <label className={`block text-sm font-medium mb-2 ${currentStyle.text}`}>
          Word Count: {wordCount}
        </label>
        <input
          type="range"
          min="100"
          max="500"
          value={wordCount}
          onChange={(e) => setWordCount(Number(e.target.value))}
          className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
        />
      </div>

      <button
        type="submit"
        className="w-full bg-white/20 text-white py-2 px-4 rounded-md hover:bg-white/30 transition-colors duration-200 shadow-sm hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-transparent border border-white/20"
      >
        Generate Story
      </button>
    </form>
  );
}