import React, { useState } from 'react';
import { StoryForm } from './components/StoryForm';
import { generateStory } from './utils/storyGenerator';
import { BookOpen } from 'lucide-react';

interface Story {
  title: string;
  content: string;
  genre: string;
}

function App() {
  const [stories, setStories] = useState<Story[]>([]);

  const handleSubmit = (data: {
    title: string;
    genre: string;
    hints: string[];
    wordCount: number;
  }) => {
    const storyContent = generateStory(data.genre, data.hints, data.wordCount);
    setStories([...stories, { title: data.title, content: storyContent, genre: data.genre }]);
  };

  const getGenreColor = (genre: string) => {
    const colors: Record<string, string> = {
      fantasy: 'bg-violet-50',
      horror: 'bg-red-50',
      adventure: 'bg-amber-50',
      historical: 'bg-sepia-50',
      romance: 'bg-pink-50',
      scifi: 'bg-blue-50',
      mystery: 'bg-emerald-50'
    };
    return colors[genre] || 'bg-white';
  };

  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-fixed"
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1516546453174-5e1098a4b4af?auto=format&fit=crop&q=80&w=2000")'
      }}
    >
      <div className="min-h-screen bg-black/30 backdrop-blur-sm">
        <header className="bg-black/40 backdrop-blur-md shadow-lg sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-2">
              <BookOpen className="text-white" size={24} />
              <h1 className="text-2xl font-bold text-white">Story Collaborator</h1>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-lg shadow-xl border border-white/20">
              <h2 className="text-lg font-semibold text-white mb-4">Create New Story</h2>
              <StoryForm onSubmit={handleSubmit} />
            </div>

            <div className="space-y-6">
              <h2 className="text-lg font-semibold text-white">Generated Stories</h2>
              {stories.length === 0 ? (
                <p className="text-white/80 bg-black/30 backdrop-blur-md p-6 rounded-lg border border-white/20">
                  No stories generated yet. Start by creating one!
                </p>
              ) : (
                stories.map((story, index) => (
                  <div 
                    key={index} 
                    className={`${getGenreColor(story.genre)} bg-opacity-90 backdrop-blur-sm p-6 rounded-lg shadow-xl border border-white/20`}
                  >
                    <h3 className="text-xl font-semibold mb-3">{story.title}</h3>
                    <p className="text-gray-700 leading-relaxed">{story.content}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;