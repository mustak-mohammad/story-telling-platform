import { storyTemplates } from '../data/storyTemplates';

function getRandomElement<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

function expandTemplate(template: string, genre: string): string {
  const genreData = storyTemplates[genre];
  let story = template;
  
  while (story.includes("{adjective}")) {
    story = story.replace("{adjective}", getRandomElement(genreData.adjectives));
  }
  
  while (story.includes("{noun}")) {
    story = story.replace("{noun}", getRandomElement(genreData.nouns));
  }
  
  while (story.includes("{verb}")) {
    story = story.replace("{verb}", getRandomElement(genreData.verbs));
  }
  
  return story;
}

export function generateStory(genre: string, hints: string[], wordCount: number): string {
  const template = getRandomElement(storyTemplates[genre].templates);
  let story = expandTemplate(template, genre);
  
  // Incorporate hints into the story
  hints.forEach(hint => {
    const sentences = [
      `This reminded everyone of ${hint}.`,
      `It was similar to ${hint} in many ways.`,
      `The situation brought ${hint} to mind.`
    ];
    story += " " + getRandomElement(sentences);
  });
  
  // Adjust story length to match word count approximately
  const currentWords = story.split(" ").length;
  if (currentWords < wordCount) {
    const additional = [
      "The implications of this were far-reaching.",
      "Nobody could have predicted what happened next.",
      "This was just the beginning of an incredible journey.",
      "The story would be told for generations to come.",
    ];
    while (story.split(" ").length < wordCount) {
      story += " " + getRandomElement(additional);
    }
  }
  
  return story;
}