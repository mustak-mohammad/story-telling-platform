interface StoryTemplate {
  genre: string;
  templates: string[];
  adjectives: string[];
  nouns: string[];
  verbs: string[];
}

export const storyTemplates: Record<string, StoryTemplate> = {
  magic: {
    templates: [
      "In a world where {noun} flowed like water, a gifted {noun} learned to {verb} the {adjective} forces of magic. Through {adjective} study and {adjective} practice, they would {verb} powers beyond imagination.",
      "The {adjective} school of {noun} held secrets that few could comprehend. When a young {noun} {verb} to master the {adjective} arts, everything changed.",
    ],
    adjectives: ["arcane", "mystical", "powerful", "ethereal", "enchanted", "supernatural", "divine"],
    nouns: ["sorcerer", "grimoire", "wand", "potion", "ritual", "amulet", "incantation"],
    verbs: ["channeled", "mastered", "wielded", "conjured", "enchanted", "invoked"]
  },
  fantasy: {
    templates: [
      "In the mystical land of {noun}, a brave {noun} discovered {noun} that would change everything. {noun} decided to {verb} across the {adjective} realm, encountering {adjective} creatures and {adjective} challenges.",
      "Deep within the {adjective} forest of {noun}, an ancient {noun} held a secret. When {noun} finally {verb} the truth, the whole kingdom {verb} in wonder.",
    ],
    adjectives: ["magical", "enchanted", "mysterious", "ancient", "ethereal", "mystical", "celestial"],
    nouns: ["wizard", "dragon", "crystal", "kingdom", "prophecy", "artifact", "spell"],
    verbs: ["discovered", "ventured", "conjured", "transformed", "awakened", "summoned"]
  },
  horror: {
    templates: [
      "In the {adjective} depths of {noun}, a {adjective} presence {verb} in the darkness. The {noun} knew that {noun} would never be the same after what they {verb} that night.",
      "The {adjective} {noun} stood silent in the moonlight, hiding secrets that would {verb} anyone who dared to enter. No one who {verb} the {noun} ever returned unchanged.",
    ],
    adjectives: ["haunted", "sinister", "eerie", "malevolent", "twisted", "dark", "cursed"],
    nouns: ["mansion", "shadow", "creature", "basement", "mirror", "whisper", "nightmare"],
    verbs: ["lurked", "haunted", "consumed", "terrorized", "emerged", "vanished"]
  },
  adventure: {
    templates: [
      "The {adjective} expedition to find the {noun} led {noun} through {adjective} territories never before explored. Each step {verb} them closer to the greatest {noun} of all time.",
      "With nothing but a {noun} and their {adjective} spirit, the {noun} {verb} into the unknown, ready to {verb} whatever challenges lay ahead.",
    ],
    adjectives: ["daring", "treacherous", "wild", "untamed", "exotic", "perilous", "magnificent"],
    nouns: ["explorer", "treasure", "map", "journey", "discovery", "expedition", "quest"],
    verbs: ["ventured", "discovered", "conquered", "survived", "explored", "achieved"]
  },
  historical: {
    templates: [
      "In the {adjective} year of 1789, a {noun} {verb} the course of history forever. The {adjective} events that followed would {verb} generations to come.",
      "During the {adjective} era, the {noun} stood as a testament to {adjective} times. When the {noun} finally {verb}, the world would never be the same.",
    ],
    adjectives: ["tumultuous", "revolutionary", "historic", "momentous", "dramatic", "pivotal", "grand"],
    nouns: ["revolution", "empire", "leader", "battle", "dynasty", "monument", "legacy"],
    verbs: ["changed", "shaped", "influenced", "transformed", "revolutionized", "marked"]
  },
  romance: {
    templates: [
      "Under the {adjective} moonlight, two souls {verb} in the most {adjective} way. The {noun} between them would {verb} despite all odds.",
      "When the {adjective} {noun} first {verb} their eyes, neither knew their {noun} would become the most {adjective} love story ever told.",
    ],
    adjectives: ["passionate", "enchanting", "romantic", "tender", "destined", "magical", "beautiful"],
    nouns: ["love", "heart", "destiny", "romance", "connection", "moment", "embrace"],
    verbs: ["blossomed", "flourished", "deepened", "endured", "transformed", "united"]
  },
  scifi: {
    templates: [
      "In the year 3045, {noun} developed a {adjective} technology that could {verb} the very fabric of space-time. The {adjective} consequences would {verb} humanity forever.",
      "Aboard the {adjective} starship {noun}, the crew encountered a {adjective} anomaly that would {verb} their understanding of reality.",
    ],
    adjectives: ["quantum", "interstellar", "cybernetic", "advanced", "futuristic", "cosmic"],
    nouns: ["scientist", "AI", "spacecraft", "dimension", "galaxy", "technology"],
    verbs: ["revolutionized", "explored", "discovered", "transformed", "engineered"]
  },
  mystery: {
    templates: [
      "The {adjective} disappearance of {noun} led Detective {noun} down a {adjective} path of investigation. Each clue {verb} to an even deeper mystery.",
      "In the {adjective} town of {noun}, a series of {adjective} events began when someone {verb} the ancient {noun}.",
    ],
    adjectives: ["mysterious", "suspicious", "enigmatic", "peculiar", "shadowy", "cryptic"],
    nouns: ["detective", "witness", "evidence", "mansion", "artifact", "suspect"],
    verbs: ["investigated", "discovered", "revealed", "uncovered", "pursued"]
  }
};